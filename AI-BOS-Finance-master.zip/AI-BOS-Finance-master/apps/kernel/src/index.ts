/**
 * AIBOS Kernel - The Brain
 * 
 * Standalone API service that enforces the AI-BOS Constitution.
 * Provides metadata, lineage, policy, and event services.
 * 
 * @see PRD_KERNEL_01_AIBOS_KERNEL.md
 */

// Load environment variables from root .env.local (monorepo setup)
// This allows sharing DATABASE_URL and other secrets from root
import { config } from 'dotenv';
import { resolve } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load root .env.local first (shared secrets), then app-level .env.local if exists
config({ path: resolve(__dirname, '../../../.env.local') });
config({ path: resolve(__dirname, '../.env.local') }); // App-level override (optional)

import { Hono } from 'hono';
import { serve } from '@hono/node-server';
import { logger } from 'hono/logger';
import { cors } from 'hono/cors';
import { checkDatabaseHealth } from './db/index.js';

// Import routes
import { metadataRoutes } from './routes/metadata.js';
import { lineageRoutes } from './routes/lineage.js';
import { policyRoutes } from './routes/policy.js';
import { eventsRoutes } from './routes/events.js';

// Create Hono app
const app = new Hono();

// Middleware
app.use('*', logger());
app.use('*', cors({
  origin: ['http://localhost:3000'], // Allow apps/web
  credentials: true,
}));

// Health check
app.get('/', (c) => {
  return c.json({
    status: 'ok',
    service: 'aibos-kernel',
    version: '0.0.0',
    timestamp: new Date().toISOString(),
  });
});

app.get('/health', (c) => {
  return c.json({
    status: 'healthy',
    service: 'aibos-kernel',
    uptime: process.uptime(),
  });
});

// Database health check
app.get('/health/db', async (c) => {
  const dbHealth = await checkDatabaseHealth();
  
  if (dbHealth.status === 'healthy') {
    return c.json({
      status: 'healthy',
      service: 'aibos-kernel',
      database: 'connected',
      latency: `${dbHealth.latency}ms`,
    });
  } else {
    return c.json({
      status: 'unhealthy',
      service: 'aibos-kernel',
      database: 'disconnected',
      error: dbHealth.error,
    }, 503);
  }
});

// Mount route handlers
app.route('/metadata', metadataRoutes);
app.route('/lineage', lineageRoutes);
app.route('/policy', policyRoutes);
app.route('/events', eventsRoutes);

// Start server
const port = Number(process.env.PORT) || 3001;

console.log(`🚀 AIBOS Kernel starting on http://localhost:${port}`);
console.log(`📋 PRD: KERNEL_01_AIBOS_KERNEL.md`);
console.log(`🧬 DNA: @aibos/schemas`);

serve({
  fetch: app.fetch,
  port,
}, (info) => {
  console.log(`✅ Kernel running on http://localhost:${info.port}`);
});
