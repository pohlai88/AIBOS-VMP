// ============================================================================
// MOTION COMPONENTS - Barrel Export
// Centralized export for lightweight animation wrappers
// ============================================================================

export { FadeIn } from './FadeIn';
export { SlideUp } from './SlideUp';
