import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface NexusCardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'glass' | 'alert';
  title?: string; // Optional header included
  action?: ReactNode; // Optional top-right action
}

export const NexusCard = ({
  children,
  className,
  variant = 'default',
  title,
  action,
}: NexusCardProps) => {
  return (
    <div
      className={cn(
        'nexus-card relative transition-all duration-300', // Base class from globals.css + relative for corners
        // Variant Logic
        variant === 'glass' && 'bg-nexus-void/60 backdrop-blur-md',
        variant === 'alert' && 'border-red-900/50 bg-red-950/10',
        className,
      )}
    >
      {/* Optional Built-in Header (Enforces Layout) */}
      {(title || action) && (
        <div className="flex items-center justify-between p-4 border-b border-nexus-structure">
          {title && (
            <div className="flex items-center gap-2">
              <div className="w-1 h-3 bg-nexus-green/50" /> {/* Decoration */}
              <span className="nexus-label text-nexus-signal">{title}</span>
            </div>
          )}
          {action && <div>{action}</div>}
        </div>
      )}

      {/* Content Area */}
      <div className="p-5">{children}</div>

      {/* Decorative Corner Markers (The "Forensic" Touch) */}
      <div className="absolute top-0 left-0 w-1 h-1 bg-nexus-structure" />
      <div className="absolute top-0 right-0 w-1 h-1 bg-nexus-structure" />
      <div className="absolute bottom-0 left-0 w-1 h-1 bg-nexus-structure" />
      <div className="absolute bottom-0 right-0 w-1 h-1 bg-nexus-structure" />
    </div>
  );
};
