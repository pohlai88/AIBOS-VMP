// Re-export utils from the canonical location
// This file exists for shadcn/ui component compatibility
export { cn } from '@/lib/utils';

