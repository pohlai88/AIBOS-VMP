// ============================================================================
// INVENTORY MODULE (INV)
// Stock management powered by the NexusCanon Kernel
// ============================================================================

export { INV01Dashboard } from './INV_01_Dashboard';

