// ============================================================================
// PAY_01 Payment Hub Page
// Route: /payments or /payment-hub
// ============================================================================

import { PAY01PaymentHub } from '@/modules/payment';

export default function PAY01PaymentHubPage() {
  return <PAY01PaymentHub />;
}

